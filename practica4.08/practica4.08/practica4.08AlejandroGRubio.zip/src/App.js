import logo from './logo.svg';
import './App.css';
import ListaCompra from './ejercicio1/ListaCompra';

function App() {
  return (
    <ListaCompra></ListaCompra>
  );
}

export default App;
