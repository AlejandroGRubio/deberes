import logo from './logo.svg';
import './App.css';
import './Ejercicio1/Taquilla';
import Taquilla from './Ejercicio1/Taquilla';

function App() {
  
  
  
  return (
    <Taquilla titulo = "Spider-Man 2" direccion = "Sam Raimi" cartelera = "https://i.etsystatic.com/6285100/r/il/7eb1c4/3503053230/il_570xN.3503053230_if9p.jpg">
      Como si Peter Parker no tuviera suficiente con sus propios problemas, estudios y su amor por Mary Jane, ahora tiene que salvar a la ciudad de un nuevo villano, el Doctor Octopus.
    </Taquilla>
  );
}

export default App;
