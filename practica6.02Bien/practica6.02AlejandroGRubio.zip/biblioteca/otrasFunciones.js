export function generarId() {
    return Math.random().toString(30).substring(2);
} 