"use strict";

//Importo la libreria.
import * as filt from "./bibilioteca/Filtro.js";



//Ejecutamos el filtro.
filt.censurarPalabra(`sexo`);

