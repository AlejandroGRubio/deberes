import logo from './logo.svg';
import './App.css';
import EstadoArray from "./ejercicio1/EstadoArray.js";
import Euromillon from './ejercicio2/Euromillon.js';



function App() {
  return (
     // <EstadoArray></EstadoArray>
     <Euromillon></Euromillon>
  );
}

export default App;
