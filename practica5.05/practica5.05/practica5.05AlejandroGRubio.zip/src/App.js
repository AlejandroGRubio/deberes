import React from 'react';
import './App.css';
import Localizador from './ejercicio1/Localizador.js';
import Colorines from './ejercicio2/Colorines.js';

function App() {
  return (

    <React.Fragment>
      {/* <Localizador/> */}
      <Colorines/>
    </React.Fragment>


    
  );
}


export default App;
