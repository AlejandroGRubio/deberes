import React from "react";
import "./css/Informacion.css";
import Peliculas from "./Peliculas";




function Informacion(props) {
    


//Por aquí van pasando los datos de las películas.
return(

    <React.Fragment>

        <Peliculas></Peliculas>





    </React.Fragment>






);






}



export default Informacion;