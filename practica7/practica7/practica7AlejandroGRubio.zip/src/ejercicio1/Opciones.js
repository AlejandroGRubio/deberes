import React from "react";


function Opciones(props) {
    //Sirve para imprimir el menú.
    return(

        <React.Fragment>

        <li><a>{props.nombre}</a></li>

        



        </React.Fragment>


    );

}

export default Opciones;







