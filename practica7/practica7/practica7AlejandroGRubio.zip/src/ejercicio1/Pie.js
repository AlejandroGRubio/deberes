import React from "react";
import "./css/Pie.css"




function Pie(props) {
    //Introduce los datos del pie de página.
    return(

        <React.Fragment>

        <footer>{props.info}</footer>




        </React.Fragment>



    );
}



export default Pie;

